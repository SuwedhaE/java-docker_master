package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class login {
	
public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Phase - 5\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://login.oracle.com/mysso/signon.jsp");
		
		WebElement email= driver.findElement(By.id("sso_username"));
		email.sendKeys("suwedha18171@ece.ssn.com");
		
		WebElement password= driver.findElement(By.id("ssopassword"));
		password.sendKeys("suwedha18171@ece.ssn.com");
		
		WebElement element = driver.findElement(By.cssSelector("#signin_button"));
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().build().perform();
		driver.navigate().forward();
		
	}
}
